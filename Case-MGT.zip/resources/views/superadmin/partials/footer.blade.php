  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2019-2020 <a href="http://ennvisio.com">Orionis Bd Team</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block text-uppercase" style="padding-right: 15px;">
      <b>Cantonment Board</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->