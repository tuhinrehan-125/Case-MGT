  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2019-2020 <a href="http://ennvisio.com">Ennvisio Digital Private Limited</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block text-uppercase">
      <b>Logistics area military police unit<!-- মিলিটারি পুলিশ,যানবাহন মামলা নিষ্পত্তি --></b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->