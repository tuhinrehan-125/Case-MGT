
@include('layouts.includes.header')
@include('layouts.includes.topmenu')
@include('layouts.includes.sidebar')
@yield('content')
@include('layouts.includes.footer')

