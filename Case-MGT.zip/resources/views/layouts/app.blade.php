@include('layouts.includes.header')
@include('layouts.includes.topmenu')
<div class="container-fluid">

    @yield('content')
</div>
@include('layouts.includes.footer')

