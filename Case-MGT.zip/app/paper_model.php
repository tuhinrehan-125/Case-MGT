<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class paper_model extends Model
{
    protected $table ="paper";
    protected $fillable = [
            'paper',
    ];
}
