<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UnitAuthApiController extends Controller
{
    //
}
