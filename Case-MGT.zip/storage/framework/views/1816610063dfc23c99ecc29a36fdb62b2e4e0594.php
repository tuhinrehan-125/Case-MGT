                            <table id="accept-table" class="table table-sm table-bordered table-striped ">
                                <thead>
                                <tr>
                                    <th>Sl.</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Vehicle Reg.No</th>
                                    <th>Total Case</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $case; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($data->name ??''); ?></td>
                                            <td><?php echo e($data->phone ??''); ?></td>
                                            <td><?php echo e($data->vehicle_number ??''); ?></td>
                                            <td><?php echo e($data->Case->count() ??''); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>

                                    <tr>
                                        <th>Sl.</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Vehicle Reg.No</th>
                                        <th>Total Case</th>
                                        
                                    </tr>
                                </tfoot>
                            </table>
                            
<?php /**PATH /home/cantonment16/public_html/case/resources/views/superadmin/pages/vehicle_track/table.blade.php ENDPATH**/ ?>