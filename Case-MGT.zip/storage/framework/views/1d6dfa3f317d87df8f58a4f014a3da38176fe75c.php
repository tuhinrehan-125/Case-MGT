<table id="forward-case" class="table table-striped table-bordered dt-responsive nowrap w-100">
    <thead>
        <tr>
            <th data-priority="2">SL</th>
            <th>Date</th>
            <th>Count Cases</th>
            
            <th data-priority="3">Actions</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $forward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->forward_date ?? ''); ?></td>
                <td><?php echo e($caseCount->where('forward_date',$data->forward_date)->count() ?? ''); ?></td>
                
            <td><a href="<?php echo e(route('unitauth.forwad.report.date',$data->forward_date ?? '')); ?>" class="btn btn-danger"><i class="fa fa-print"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th data-priority="2">SL</th>
                <th>Date</th>
                <th>Count Cases</th>
                
                <th data-priority="3">Actions</th>
            </tr>
        </tfoot>
        </table>
        <?php echo e($forward->links()); ?>

<?php /**PATH D:\Projects\Case-MGT\resources\views/unitauth/forward-report-table.blade.php ENDPATH**/ ?>