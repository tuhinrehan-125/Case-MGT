<?php $__env->startSection('content'); ?>
<div class="login-area section-padding">
    <div class="container-fluid px-3">
        <div class="row justify-content-center">
        <div class="col-md-8">
        <h3 class="text-center m-3">Witdraw Case</h3>
        <div class="card m-2 text-danger">
        <p class="p-1">
        
        </p>
        </div>
        <table class="table table-striped table-bordered">
            <tr>
                <th width="50%">Case No</th>
                <td><?php echo e($case->case_no?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Victime Name</th>
                <td><?php echo e($case->victim_name?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Mobile No.</th>
                <td><?php echo e($case->victim_mb?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Vehicle Reg no.</th>
                <td><?php echo e($case->vehical_reg?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Vehicle Type</th>
                <td><?php echo e($case->vehical_type?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Victim</th>
                <td><?php echo e($case->victim?? ''); ?></td>
            </tr>
            <tr>
                <th width="50%">Crime List</th>
                <td>
                    <?php if($case->crime_type!='null' && count( json_decode($case->crime_type) ) >0 ): ?>
                        <?php $__currentLoopData = json_decode($case->crime_type); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($crime->where('id',$cdata)->first()->crime ?? ''); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th width="50%">Paper Ceased</th>
                <td>
                    <?php if(($case->paper)!='null' && count(json_decode($case->paper) ) >0): ?>
                        <?php $__currentLoopData = json_decode($case->paper); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($pdata ?? ''); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th width="50%">Unit</th>
                <td><?php echo e($case->unit->name?? ''); ?></td>
            </tr>
            <!-- <tr>
                <th width="50%">Fine</th>
                <td><?php echo e($case->veh_reg_no?? ''); ?></td>
            </tr> -->
        </table>
                <form action="<?php echo e(route('withdraw.request')); ?>" method="post" class="col-md-12 col-lg-12">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="case_id" value="<?php echo e($case->id); ?>">
                    <div class="form-group row justify-content-center">
                        <label for="fine" class="col-sm-2 col-form-label">Fine</label>
                        <div class="col-sm-6">
                            <input type="text" name="fine" class="form-control" id="fine" value="<?php echo e($total); ?>" readonly>
                        </div>
                    </div>
                    <?php if($consider): ?>
                    <div class="form-group row justify-content-center">
                        <label for="fine" class="col-sm-2 col-form-label">Consideration</label>
                        <div class="col-sm-6">
                            <input type="text" name="consideration" class="form-control" id="fine" value="<?php echo e($consider ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="form-group row justify-content-center">
                        <label for="comments" class="col-sm-2 col-form-label ">Service Charge</label>
                        <div class="col-sm-6">
                         <input type="number" min="0" value="50" name="service_charge" class="form-control" id="total" readonly>
                        </div> 
                    </div>
                    <div class="form-group row justify-content-center">
                        <label for="total" class="col-sm-2 col-form-label">Total</label>
                        <div class="col-sm-6">
                            <input type="number" min="0" value="<?php echo e($total+50-$consider); ?>" name="total" class="form-control" id="total" readonly>
                        </div>
                    </div>

                    
                    <div class="form-group row justify-content-center">
                        <label for="comments" class="col-sm-2 col-form-label ">Courier Address</label>
                        <div class="col-sm-6">
                            <textarea name="courier_address" class="form-control" id="courier_address" required></textarea>
                        </div>
                    </div>
                    <div class="form-group row justify-content-center">
                        <button class="btn btn-info">Pay Now</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $('#new-case').DataTable();
        });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cantonment16/public_html/case/resources/views/user-side/pages/withdraw-case.blade.php ENDPATH**/ ?>