<?php $__env->startSection('content'); ?>
<div class="login-area section-padding">
    <div class="container-fluid px-3">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h3 class="">Old Case List</h3>
                <table id="new-case" class="table table-striped table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Sl.</th>
                            <th>Case No.</th>
                            <th>Name</th>
                            <th>Location</th>
                            <th>Crime</th>
                            <th>Paper Collect</th>
                            <th>Unit</th>
                            <th>Status</th>
                            <th>Release Date</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php $__currentLoopData = $case; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$csData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($csData->case_no ?? ''); ?></td>
                                <td><?php echo e($csData->victim_name ?? ''); ?></td>
                                <td><?php echo e($csData->loc ?? ''); ?></td>
                                <td>
                                <?php if($csData->crime_type!='null' && count( json_decode($csData->crime_type) ) >0 ): ?>
                                        <?php $__currentLoopData = json_decode($csData->crime_type); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($crime->where('id',$cdata)->first()->crime ?? ''); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                <?php if(($csData->paper)!='null' && count(json_decode($csData->paper) ) >0): ?>
                                        <?php $__currentLoopData = json_decode($csData->paper); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($pdata ?? ''); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($csData->unit->name ?? ''); ?></td>
                                <td>
                                        <p class="text-light bg-success rounded-circle p-2">Released</p>
                                </td>
                            <td><?php echo e($csData->ReleaseCase->release_date ?? ''); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Sl.</th>
                        <th>Case No.</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Crime</th>
                        <th>Paper Collect</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Release Date</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $('#new-case').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cantonment16/public_html/case/resources/views/user-side/pages/old-case.blade.php ENDPATH**/ ?>