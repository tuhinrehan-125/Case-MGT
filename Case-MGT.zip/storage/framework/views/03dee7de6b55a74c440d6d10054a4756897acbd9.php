
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
            </li>
         </ul>
<div class="row justify-content-center w-100">
    <h3 class="text-uppercase text-center  text-bold" ><?php if(Auth::user()->unit_id==1): ?> LOGISTICS AREA MILITARY POLICE UNIT  <?php elseif(Auth::user()->unit_id==2): ?> BANGLADESH ARMY MILITARY POLICE UNIT <?php else: ?> BANGLADESH AIRFORCE MILITARY POLICE UNIT <?php endif; ?></h3>
</div>
    











        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <img src="<?php echo e(!empty(Auth::user()->image) ? asset(Auth::user()->image) : asset('/unit-user/image/avatar.png')); ?>" class="img-circle elevation-2" alt="User Image" height="50px" width="50px" style="margin-top: -14px;">

                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-item dropdown-header">Menu</span>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('unitauth.unit.user.profile')); ?>" class="dropdown-item">
                        <i class="fas fa-user mr-2"></i> Profile
                    </a>





                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(url('/unitauth/logout')); ?>" class="dropdown-item"  onclick="event.preventDefault();  document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
                    </a>
                    <form id="logout-form" action="<?php echo e(url('/unitauth/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                    <div class="dropdown-divider"></div>
                </div>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

<?php /**PATH /home/cantonment16/public_html/case/resources/views/unitauth/includes/top-header.blade.php ENDPATH**/ ?>