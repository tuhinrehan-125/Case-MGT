
<table id="forward-table-data" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline collapsed ">
    <thead>
    <tr>
        
        
        <th>Case No.</th>
        <th>Name</th>
        <th>Mobile No.</th>
        <th>Vehicle Reg.No</th>
        <th>Date of Forwarding</th>
        <th>Unit</th>
        <th>Status</th>
        <th >Action</th>
    </tr>
    </thead>
<tbody>
    <?php if($cases): ?>
<?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($data->CaseDetails->case_no ?? ''); ?></td>
<td><?php echo e($data->CaseDetails->victim_name ?? ''); ?></td>
<td><?php echo e($data->CaseDetails->victim_mb ?? ''); ?></td>
<td><?php echo e($data->CaseDetails->vehical_reg ?? ''); ?></td>
<td><?php echo e($data->forward_date ?? ''); ?></td>
<td><?php echo e($data->Unit->name ?? ''); ?></td>
<td>
    <?php if($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==0 && $data->release_status==0): ?>
    Forwarded
    <?php elseif($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==1 && $data->release_status==0): ?>
    Accepted
    <?php elseif($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==1 && $data->release_status==1): ?>
    Released
    <?php elseif($data->forward_status==1 && $data->drop_status==1 && $data->delete_status==1): ?>
    Droped
    <?php endif; ?>
</td>
<td>
<table>
    <tr>
        <td>
            <button class="btn btn-md btn-info view-data" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>"
            >Detail</button>
        </td>
        <?php if($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==0 && $data->release_status==0): ?>
        <td>
            <button class="btn btn-md btn-success edit-data" data-toggle="modal"  data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>" data-target="#exampleaccept">Accept</button>
        </td>
        <?php endif; ?>
        <?php if($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==1 && $data->release_status==0): ?>

       <td> <button class="btn btn-md btn-success release" data-box="<?php echo e($data->box_no ?? ''); ?>" data-forward_id="<?php echo e($data->id ?? ''); ?>" data-toggle="modal" data-id="<?php echo e($data->CaseDetails->id); ?>" data-target="#exampleaccept-release"
        >Release</button></td>
        <?php endif; ?>
        <?php if($data->forward_status==1 && $data->drop_status==0 && $data->delete_status==1 && $data->accept_status==1 && $data->release_status==1): ?>
        <td>
            <a href="<?php echo e(route('superadmin.print.invoice',$data->case_id)); ?>" class="btn btn-md btn-danger " data-id="<?php echo e($data->id); ?>" target="_blank"><i class="fa fa-print"></i>Print</a>
        </td>
        <?php endif; ?>
        <?php if(Auth::user()->role_id==1 || Auth::user()->role_id==2): ?>

        <?php if($data->drop_status==0 && $data->delete_status==1  && $data->release_status==0): ?>
            <?php if(Auth::user()->role_id==2 && $data->consider==null): ?>
            <td>
            <button class="btn btn-md btn-secondary discount-btn" data-toggle="modal" data-target="#consider-modal "  data-case_id="<?php echo e($data->CaseDetails->id); ?>" >Consider <?php echo e($data->consider); ?></button>
            </td>
            <?php endif; ?>
        <td>
            <button class="btn btn-md btn-danger drop-btn" data-box="<?php echo e($data->box_no ?? ''); ?>" data-forward_id="<?php echo e($data->id ?? ''); ?>" data-toggle="modal" data-target="#drop-modal "  data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>" >Drop</button>
        </td>
        <?php endif; ?>
        <?php if($data->drop_status==1 && $data->delete_status==1 && $data->accept_status==1 && $data->release_status==0): ?>

        <td>
            <a href="<?php echo e(route('superadmin.undo.drop',$data->case_id)); ?>" class="btn btn-md btn-danger" data-id="<?php echo e($data->CaseDetails->id); ?>"
            onclick="return confirm('Are you sure')">Undo Drop </a>
        </td>
        <?php endif; ?>
        <?php endif; ?>

    </tr>
</table>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
    <tfoot>
    <tr>
        <th>Case No.</th>
        <th>Name</th>
        <th>Mobile No.</th>
        <th>Vehicle Reg.No</th>
        <th>Date of Forwarding</th>
        <th>Unit</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    </tfoot>
</table>
<?php if($cases): ?>

<?php echo e($cases->links()); ?>

<?php endif; ?>
<?php /**PATH E:\laragon\www\case_management\resources\views/superadmin/pages/case/case-finder-table.blade.php ENDPATH**/ ?>