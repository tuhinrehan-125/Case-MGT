                        <table id="account-table" class="table table-bordered table-striped text-center">
                                <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Unit</th>
                                    <th>
                                   <p class="text-center"> Cases</p>
                                       <table class="table ">
                                       <tr>
                                            <th width="25%">Total</th>
                                            <th width="25%">Accept Cases</th>
                                            <th width="25%">Drop Cases</th>
                                            <th width="25%">Release Cases</th>
                                        </tr>
                                       </table>
                                    </th>
                                    <th>Total Collection of amount</th>
                                    <th >
                                    <table class="table ">
                                       <tr>
                                       <p class="text-center">Through</p>
                                            <th width="40%">Cash</th>
                                            <th width="40%">Online Banking</th>
                                        </tr>
                                       </table>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $query_date = date("Y").'-'.$data.'-'.'01';
                                    $startDate= date('Y-m-01', strtotime($query_date));
                                    $endDate= date('Y-m-t', strtotime($query_date));
                                    $collection= $release->whereBetween('release_date',[$startDate, $endDate])->sum('total');
                                    $dateObj   = DateTime::createFromFormat('!m', $data);
                                    $monthName = $dateObj->format('F');
                                    ?>
                                <tr>
                                <td>
                                <?php echo e($monthName); ?>-<?php echo e(date("Y")); ?>

                                <br>
                                <?php echo e($startDate); ?>

                                <br>
                                <?php echo e($endDate); ?>

                                 </td>
                                    <td>
                                       <table class="table ">
                                       <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $udata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                            <td><?php echo e($udata->name ?? ''); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </table>
                                    </td>
                                    <td>
                                       <table class="table ">
                                       <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $udata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $total=$forward->whereBetween('forward_date',[$startDate,$endDate])->where('unit_id',$udata->id)->count();
                                        $acp=$forward->whereBetween('accept_date',[$startDate,$endDate])->where('accept_status',1)->where('forward_status',1)->where('unit_id',$udata->id)->count();
                                        $drop=$forward->whereBetween('forward_date',[$startDate,$endDate])->where('drop_status',1)->where('unit_id',$udata->id)->count();
                                        $rdata= $release->whereBetween('release_date',[$startDate,$endDate])->where('unit_id',$udata->id)->count();
                                        ?>
                                       <tr>
                                            <td width="25%"><?php echo e($total); ?></td>
                                            <td width="25%"><?php echo e($acp); ?></td>
                                            <td width="25%" class="text-danger"><?php echo e($drop); ?></td>
                                            <td width="25%"><?php echo e($rdata); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </table>
                                    </td>
                                    <td><?php echo e($collection); ?></td>
                                    <td >
                                    <table class="table ">
                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $udata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $cash=$account->whereBetween('date',[$startDate,$endDate])->where('unit_id',$udata->id)->where('payment_method','Cash')->sum('total');
                                    $mobile=$account->whereBetween('date',[$startDate,$endDate])->where('unit_id',$udata->id)->where('payment_method','!=','Cash')->sum('total');
                                 ?>
                                       <tr>
                                            <td  width="40%"><?php echo e($cash); ?></td>
                                            <td width="40%"><?php echo e($mobile); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </table>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                                <tfoot>
                                <tr>
                                    <th colspan="2">Total all </th>
                                    <th>
                                    <table class="table ">
                                       <?php
                                       $total_cases=$forward->count();
                                       $acp_cases=$forward->where('accept_status',1)->where('forward_status',1)->count();
                                       $drop_cases=$forward->where('drop_status',1)->count();
                                       $rdata_relased=$release->count();
                                       ?>
                                       <tr>
                                            <td width="25%"><?php echo e($total_cases); ?></td>
                                            <td width="25%"><?php echo e($acp_cases); ?></td>
                                            <td width="25%" class="text-danger"><?php echo e($drop_cases); ?></td>
                                            <td width="25%"><?php echo e($rdata_relased); ?></td>
                                        </tr>
                                       </table>
                                    </th>
                                    <th>
                                    <?php echo e($release->sum('total')); ?>

                                    </th>
                                    <th >
                                    <table class="table ">
                                    <?php
                                    $cash_total=$account->where('payment_method','Cash')->sum('total');
                                    $mobile_total=$account->where('payment_method','!=','Cash')->sum('total');
                                    ?>
                                       <tr>
                                            <td  width="40%"><?php echo e($cash_total); ?></td>
                                            <td width="30%"><?php echo e($mobile_total); ?></td>
                                        </tr>
                                       </table>
                                    </th>
                                </tr>
                                </tfoot>
                            </table>
<?php /**PATH E:\laragon\www\case_management\resources\views/superadmin/pages/reports/monthly-report-table.blade.php ENDPATH**/ ?>