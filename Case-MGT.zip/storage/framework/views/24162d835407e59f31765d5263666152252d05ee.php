<?php $__env->startSection('content'); ?>
<div class="row m-3">
    <div class="col-md-6 col-lg-6 col-sm-12">
        <u><h2 class="text-center font-weight-bold">Type of case</h2></u>
        <table class="table" id="cases-table">
            <thead>
                <th>SL</th>
                <th>Name</th>
                <th>Fine</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $crime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->crime?? ''); ?></td>
                <td><?php echo e($data->fine_crime?? 0); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <th>SL</th>
                <th>Name</th>
                <th>Fine</th>
            </tfoot>
        </table>


    </div>
    <div class="col-md-6 col-lg-6 col-sm-12">
        <div class="login-area section-padding" style="margin-top: 200px">
            <div class="container-fluid p-3">
                <div class="row justify-content-center">
                    <div class="col-md-10">
                        <div class="card">

                <div class="card-header text-center text-light form-head" style="background-color: #0d6920;"><?php echo e(__('Login')); ?></div>

                <div class="card-body  p-3">
                    <form method="POST" action="<?php echo e(route('user.verify.login')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="email" value="<?php echo e($email ?? ''); ?>">
                        <input type="hidden" name="password" value="<?php echo e($password ?? ''); ?>">

                        <div class="form-group row">
                            <label for="code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Code')); ?></label>

                            <div class="col-md-6">
                            <input id="code" type="text" class="form-control " value="<?php echo e($code); ?>" name="code" >
                                <span id="error_code"></span>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4" >
                                <button type="submit" id="login" class="btn btn-primary" >
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready(function() {
            var code ='<?php echo e($code ?? ''); ?>';
            $("#code").keyup(function () {
                var form=$(this).val();
                if(code==form){

                    $('#login').prop('disable',false);
                    $('#error_code').html('<label class="text-success"><b>Your code is valid</b></label>');
                    $('#code').removeClass('has-error');
                    $('#login').attr('disabled', false);
                    // $('#login').css('display', 'block');
                }else{
                    $('#error_code').html('<label class="text-danger"><b>Your Code is invalid or time out</b></label>');
                    $('#code').addClass('has-error');
                    $('#login').attr('disabled', 'disabled');
                    // $('#login').css('display', 'none');
                }
            })
        })
        $(document).ready(function(){
            $("#cases-table").DataTable();
        })
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cantonment16/public_html/case/resources/views/user-side/verify-login.blade.php ENDPATH**/ ?>