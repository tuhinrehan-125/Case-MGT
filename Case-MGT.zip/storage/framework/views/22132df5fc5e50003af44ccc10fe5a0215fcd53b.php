<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col unitlogo">
            <img src="<?php echo e(asset('/frontend/image/logo.png')); ?>" alt="logo">
        </div>
    </div>
    <div class="unit-panel">
        <div class="form-container sign-in-container">
            <form class="unitsignin" role="form" method="POST" action="<?php echo e(url('/unitauth/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <h2>Unit Signin</h2>
                    <input id="email" type="text" name="email" placeholder="email" value="<?php echo e(old('email')); ?>" autofocus>
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <input id="password" type="password" placeholder="password" name="password" value="" autofocus>
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                <a  href="<?php echo e(url('/unitauth/password/reset')); ?>">Forgot your password?</a>
                <button type="submit">Sign In</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel">
                    <h1>Dhaka Cantonment Board</h1>
                    <h3>Case Management Software</h3>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('unitauth.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Case-MGT\resources\views/unitauth/auth/login.blade.php ENDPATH**/ ?>