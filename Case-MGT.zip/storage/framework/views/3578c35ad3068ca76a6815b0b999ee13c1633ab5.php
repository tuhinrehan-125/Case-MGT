<table id="case-table" class="table table-sm table-bordered table-striped ">
                                <thead>
                                <tr>
                                    <th>Sl.</th>
                                    <th>Case No.</th>
                                    <th>Banking</th>
                                    <th>Transaction ID</th>
                                    <th>Querier </th>
                                    <th>Paid Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $checkWithdra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($data->CaseDetails->case_no ?? ''); ?></td>
                                    <td><?php echo e($data->bank_branch ?? ''); ?></td>
                                    <td><?php echo e($data->tax_transaction_id ?? ''); ?></td>
                                    <td><?php echo e($data->courier_address ?? ''); ?></td>
                                    <td><?php echo e($data->total ?? ''); ?></td>
                                    <td><?php echo e($data->status ?? ''); ?></td>
                                    <td><?php echo e($data->created_at->format('d-m-Y') ?? ''); ?></td>
                                    <td>
                                    <table>
                                        <tr>
                                            <td>
                                                <button class="btn btn-md btn-info view-data" data-toggle="modal" data-target="#view" data-id="<?php echo e($data->CaseDetails->id); ?>">Detail</button>
                                            </td>
                                            <td>
                                            <button class="btn btn-md btn-success payment-confirm edit-data" data-box="<?php echo e($data->box_no ?? ''); ?>" data-withdraw_id="<?php echo e($data->id); ?>"  data-qurier_address="<?php echo e($data->courier_address ?? ''); ?>"   data-id="<?php echo e($data->CaseDetails->id); ?>">Confirm</button>
                                            </td>
                                        </tr>
                                    </table>
                                    </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                <tfoot>
                                    <tr>
                                        <th>Sl.</th>
                                        <th>Case No.</th>
                                        <th>Banking</th>
                                        <th>Transaction ID</th>
                                        <th>Querier </th>
                                        <th>Paid Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                            <?php echo e($checkWithdra->links()); ?>

<?php /**PATH E:\laragon\www\case_management\resources\views/superadmin/pages/withdraw-request/table.blade.php ENDPATH**/ ?>