<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

     <!-- Font Awesome -->
     <link rel="stylesheet" href="<?php echo e(asset('/backend/plugins/fontawesome-free\css\all.min.css')); ?>">

     <link rel="icon" type="image/png" href="<?php echo e(asset('/frontend/assets/images/favicon.png')); ?>">
     <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
     <!-- Theme style -->
     <link rel="stylesheet" href="<?php echo e(asset('/backend/dist/css/adminlte.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <style>
    html, body {
        background-color: #fff;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 100;
        height: 100vh;
        margin: 0;
    }

    .full-height {
        height: 100vh;
    }

    .flex-center {
        align-items: center;
        display: flex;
        justify-content: center;
    }

    .position-ref {
        position: relative;
    }

    .code {
        border-right: 2px solid;
        font-size: 26px;
        padding: 0 15px 0 15px;
        text-align: center;
    }

    .message {
        font-size: 18px;
        text-align: center;
    }
    .content-wrapper {
    background: white;
    }
</style>
</head>
<body >
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content">
        <div class="flex-center position-ref full-height">
        <div class="error-page ">
            <h2 class="headline text-danger"><?php echo $__env->yieldContent('code'); ?></h2>
            <div class="error-content" style="margin-bottom: -200px">
                <div class="error-content mt-5">
                    <div class="message" style="padding: 10px;">
                        <h3><i class="fas fa-exclamation-triangle text-danger"></i> Oops! <?php echo $__env->yieldContent('message'); ?>.</h3>
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-primary"><i class="fas fa-backward"></i> Back </a>
                    </div>
                </div>
            </div>
          </div>
        </div>
      <!-- /.error-page -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php echo $__env->make('superadmin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Control Sidebar -->
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="<?php echo e(asset('/backend/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('/backend/dist/js/demo.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/cantonment16/public_html/case/resources/views/errors/minimal.blade.php ENDPATH**/ ?>