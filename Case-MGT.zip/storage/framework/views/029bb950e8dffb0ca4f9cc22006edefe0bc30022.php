<table id="forward-case" class="table table-striped table-bordered dt-responsive nowrap w-100">
                <thead>
                <tr>
                  <th>Sl.</th>
                  <th>Case No.</th>
                  <th>Name</th>
                  <th>Mobile No.</th>
                  <th>Vehicle Reg.No</th>

                  <th>Date offence</th>
                  <th>Time offence</th>
                  <th>Date Diposal</th>
                  <!--<th>Time Diposal</th>-->
                  <th>Location</th>

                  <th>Vehical Type</th>
                  <th>Case Type</th>
                  <th>Victim Type</th>
                  <th>Name of MP</th>
                  <th>Paper Ceased</th>
                </tr>
                </thead>
              <tbody>
              <?php $__currentLoopData = $forwared_case; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->case_no); ?></td>
                <td><?php echo e($data->victim_name); ?></td>
                <td><?php echo e($data->victim_mb); ?></td>
                <td><?php echo e($data->vehical_reg); ?></td>

                <td><?php echo e($data->date_off); ?></td>
                <td><?php echo e($data->time_off); ?></td>
                <td><?php echo e($data->date_disposal); ?></td>
                <!--<td><?php echo e($data->time_disposal); ?></td>-->
                <td><?php echo e($data->loc); ?></td>

                <td><?php echo e($data->vehical_type); ?></td>
                <td>
                <?php if($data->crime_type!='null'): ?>
                    <?php $__currentLoopData = json_decode($data->crime_type, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cr=$crimes->where('id',$info ?? '')->first();
                        ?>
                        <?php echo e($cr->crime ?? ''); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    Null
                <?php endif; ?>
                </td>
                <td><?php echo e($data->victim); ?></td>
                <td><?php echo e(!empty($data->Unitauth->name) ? $data->Unitauth->name : ''); ?></td>
                <td>
                    <?php if($data->paper == 'null'): ?>
                        null
                    <?php else: ?>
                        <?php $__empty_1 = true; $__currentLoopData = json_decode($data->paper, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datapaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php echo e($datapaper); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                            <?php if(empty($data->paper_number)): ?>
                            <?php else: ?>
                            (<?php echo e($data->paper_number); ?>)
                            <?php endif; ?>
                    <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              </table>

              <?php echo e($forwared_case->links()); ?><?php /**PATH E:\laragon\www\case_management\resources\views/unitauth/pages/cases/forwardcase-table.blade.php ENDPATH**/ ?>