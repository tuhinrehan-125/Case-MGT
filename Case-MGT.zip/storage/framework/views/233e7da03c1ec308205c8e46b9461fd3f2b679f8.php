
                                <table id="case_finder" class="table table-striped table-bordered dt-responsive nowrap" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th data-priority="1">Sl.</th>
                                        <th data-priority="2">Case No.</th>
                                        <th>Name</th>
                                        <th>Mobile No.</th>
                                        <th>Vehicle Reg.No</th>
                                        <th>Date of offence</th>
                                        <th>Time of offence</th>
                                        <th>Date Disposal</th>
                                        <th>Location</th>
                                        <th>Vehicle Type</th>
                                        <th>Case Type</th>
                                        <th>Victim Type</th>
                                        <th>Name of MP</th>
                                        <th>Paper Ceased</th>
                                        <th data-priority="3">Status</th>

                                        <th data-priority="4">Actions</th>
                                    </tr>
                                    </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $case; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($data->case_no); ?></td>
                                                    <td><?php echo e($data->victim_name); ?></td>
                                                    <td><?php echo e($data->victim_mb); ?></td>
                                                    <td><?php echo e($data->vehical_reg); ?></td>
                                                    <td><?php echo e($data->date_off); ?></td>
                                                    <td><?php echo e($data->time_off); ?></td>
                                                    <td><?php echo e($data->date_disposal); ?></td>
                                                    <td><?php echo e($data->loc); ?></td>
                                                    <td><?php echo e($data->vehical_type); ?></td>
                                                    <td>
                                                    <?php if($data->crime_type!='null'): ?>
                                                    <?php $__currentLoopData = json_decode($data->crime_type ?? '', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $cr=$crimes->where('id',$info ?? '')->first();
                                                        ?>
                                                        <?php echo e($cr->crime ?? ''); ?>,
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    Null
                                                <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($data->victim); ?></td>
                                                    <td><?php echo e(!empty($data->Unitauth->name) ? $data->Unitauth->name : ''); ?></td>
                                                    <td>

                                                        <?php if($data->paper == 'null'): ?>
                                                            null
                                                        <?php else: ?>
                                                            <?php $__empty_1 = true; $__currentLoopData = json_decode($data->paper, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datapaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <?php echo e($datapaper); ?>,
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <?php endif; ?>
                                                            
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($data->forwared==0 && $data->drop_type==0): ?>
                                                        Pendding
                                                        <?php elseif($data->forwared==1 && $data->drop_type==0): ?>
                                                        Forwarded
                                                        <?php elseif($data->forwared==0 && $data->drop_type==1): ?>
                                                        Dropped
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <table class="d-block action-table">
                                                                <tr class="<?php echo e($data->id && ($data->forwared=='0' && $data->drop_type=='0' && $data->delete_status=='1')  ? 'd-block' : 'd-none'); ?>">
                                                                    <?php if($data->forwared=='0'): ?>
                                                                    <td>
                                                                        <a href="" class="btn btn-sm btn-info edit-btn-case-desk" data-toggle="modal" data-id="<?php echo e($data->id); ?>" data-target="#exampleModaledit">
                                                                        <!-- <i class="fas fa-pencil-alt"> -->
                                                                        </i> Edit
                                                                        </a>
                                                                    </td>
                                                                    <td>
                                                                    <a href="#" name="buttton" value="singleforward" data-id="<?php echo e($data->id); ?>"  class="btn btn-sm btn-danger btn-forward">Forward</a>
                                                                    </td>
                                                                    <?php endif; ?>
                                                                    <?php if(Auth::user()->unit_role_id==1 && $data->forwared=='0'): ?>
                                                                    <td>
                                                                        <a href="#"  data-id="<?php echo e($data->id); ?>" onclick="return confirm(\'Are you sure you want to drop this case?\');" class="btn btn-danger drop-btn">
                                                                            Drop
                                                                        </a>
                                                                    </td>
                                                                    <?php endif; ?>
                                                                </tr>
                                                            </td>
                                                        </table>
                                                    </td>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            </tbody>
                                        </table>
<?php /**PATH /home/cantonment16/public_html/case/resources/views/unitauth/case_finder_table.blade.php ENDPATH**/ ?>