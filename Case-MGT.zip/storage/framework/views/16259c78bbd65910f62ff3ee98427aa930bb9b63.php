<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-green"><i class="fas fa-star mr-1"></i> Crime </h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#" class="text-green">Home</a></li>
                            <li class="breadcrumb-item active text-green">Crime </li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">

                    <div class="col-lg-12 col-12">
                        <div class="card card-success card-outline">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-star mr-1"></i>
                                    <b>Add Crime Type</b>
                                    <!--Error handaler-->
                                    <?php if($errors->any()): ?>
                                        <span class="help-block text-red errorrr">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($error); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </span>
                                <?php endif; ?>

                                <!-- Error handaler -->
                                </h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('superadmin.crime')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="type" value="cantroment">

                                    <div class="form-group">
                                        <label for="vehicle" col-lg-2">Crime Type</label>
                                        <input type="text" class="form-control col-lg-4" name="crime" id="crime" placeholder="Type Crime Type">
                                        <?php if($errors->has('crime')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('crime')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="fine_crime" col-lg-2">Fine Amount</label>
                                        <input type="text" class="form-control col-lg-4" name="fine_crime" id="fine_crime" placeholder="Fine Amount">
                                        <?php if($errors->has('fine_crime')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('fine_crime')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>


                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success"><span><i class="fa fa-plus" aria-hidden="true"></i></span>ADD</button>
                            </div>
                            </form>
                        </div>
                    </div>



                    <div class="col-lg-12 col-12">
                        <div class="card card-success card-outline">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <!-- <i class="fas fa-map-marker mr-1"></i> -->
                                    <b>All Crime List </b>
                                </h3>
                            </div>
                            <div class="card-body">

                                <table class="table table-bordered table-striped example1">
                                    <thead>
                                    <tr>
                                        <th>Sl./No</th>
                                        <th>Crime list</th>
                                        <th>Fine Amount</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $crime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->crime); ?></td>
                                            <td><?php echo e($data->fine_crime); ?></td>
                                            <td>
                                                <a class="btn btn-info btn-sm" href="#" data-toggle="modal" data-target="#exampleModalCenter<?php echo e($data->id); ?>">
                                                    <i class="fas fa-pencil-alt">
                                                    </i>
                                                    Edit
                                                </a>
                                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('superadmin.crime_delete',$data->id)); ?>" onclick="return confirm('Do you want to suer')">
                                                    <i class="fas fa-trash">
                                                    </i>
                                                    Delete
                                                </a>
                                                <!-- Edit -->
                                                <div class="modal fade" id="exampleModalCenter<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                    <div class="modal-dialog model-md" role="document">


                                                        <form action="<?php echo e(route('superadmin.crime_update',$data->id)); ?>" method="POST">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('PATCH')); ?>

                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLongTitle">Change Crime Name</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">

                                                                    <div class="form-group">
                                                                        <label for="vehicle" col-lg-2">Crime Type</label>
                                                                        <input type="text" class="form-control col-lg-12" name="crime" value="<?php echo e($data->crime); ?>" id="crime" placeholder="Type Crime Type">
                                                                        <?php if($errors->has('crime')): ?>
                                                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('crime')); ?></strong>
                                    </span>
                                                                        <?php endif; ?>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="fine_crime" col-lg-2">Fine Amount</label>
                                                                        <input type="text" class="form-control col-lg-12" name="fine_crime" value="<?php echo e($data->fine_crime); ?>" id="fine_crime" placeholder="Fine Amount">
                                                                        <?php if($errors->has('fine_crime')): ?>
                                                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('fine_crime')); ?></strong>
                                    </span>
                                                                        <?php endif; ?>
                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
                                                                    <button type="submit" class="btn btn-success">Save changes</button>
                                                                </div>
                                                            </div>
                                                        </form>


                                                    </div>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cantonment16/public_html/case/resources/views/superadmin/pages/crime/mpcrime.blade.php ENDPATH**/ ?>