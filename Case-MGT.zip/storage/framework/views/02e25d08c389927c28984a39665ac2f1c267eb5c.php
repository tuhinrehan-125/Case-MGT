    <table id="forward-table-data" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline collapsed ">
        <thead>
        <tr>
            <th>Sl.</th>
            <th>Select</th>
            <th>Case No.</th>
            <th>Name</th>
            <th>Mobile No.</th>
            <th>Vehicle Reg.No</th>
            <th>Date of Forwarding</th>
            <th>Unit</th>
            <th>Date Disposal</th>
            <th>Vehicle Type</th>
            <th >Action</th>
        </tr>
        </thead>
    <tbody>
    <?php $__currentLoopData = $forward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($loop->iteration); ?></td>
    <td><span class="icheck-success d-inline "><input type="checkbox" class="select-field" id="newcase1<?php echo e($data->CaseDetails->id ?? ''); ?>" name="chk[]" value="<?php echo e($data->CaseDetails->id ?? ''); ?>">
            <label for="newcase1<?php echo e($data->CaseDetails->id ?? ''); ?>"></label>
        </span>
    </td>
    <td><?php echo e($data->CaseDetails->case_no ?? ''); ?></td>
    <td><?php echo e($data->CaseDetails->victim_name ?? ''); ?></td>
    <td><?php echo e($data->CaseDetails->victim_mb ?? ''); ?></td>
    <td><?php echo e($data->CaseDetails->vehical_reg ?? ''); ?></td>
    <td><?php echo e($data->forward_date ?? ''); ?></td>
    <td><?php echo e($data->Unit->name ?? ''); ?></td>
    <td><?php echo e($data->CaseDetails->date_disposal ?? ''); ?></td>
    <td><?php echo e($data->CaseDetails->vehical_type ?? ''); ?></td>
    <td>
    <table>
        <tr>
            <td>
                <button class="btn btn-md btn-info view-data" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>"
                >Detail</button>
            </td>
            <td>
                <button class="btn btn-md btn-success edit-data" data-toggle="modal"  data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>" data-target="#exampleaccept">Accept</button>
                <?php if(Auth::user()->role_id==1 || Auth::user()->role_id==2): ?>
                <button class="btn btn-md btn-danger drop-btn" data-box="<?php echo e($data->box_no ?? ''); ?>" data-forward_id="<?php echo e($data->id ?? ''); ?>" data-toggle="modal" data-target="#drop-modal "  data-id="<?php echo e($data->CaseDetails->id ?? ''); ?>" >Drop</button>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
        <tfoot>
        <tr>
            <th>Sl.</th>
            <th>Select</th>
            <th>Case No.</th>
            <th>Name</th>
            <th>Mobile No.</th>
            <th>Vehicle Reg.No</th>
            <th>Date of Forwarding</th>
            <th>Unit</th>
            <th>Date Disposal</th>
            <th>Vehicle Type</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>

<?php echo e($forward->links()); ?>

<?php /**PATH D:\Projects\Case-MGT\resources\views/superadmin/pages/case/forward-table.blade.php ENDPATH**/ ?>