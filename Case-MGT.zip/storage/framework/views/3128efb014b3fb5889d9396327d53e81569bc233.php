
<table>
    <tr>
        <td>
            <a href="#"
               data-id="<?php echo e(!empty($data->id) ? $data->id : ''); ?>"
               data-name="<?php echo e(!empty($data->name) ? $data->name : ''); ?>"
               data-unit="<?php echo e(!empty($data->unit_id) ? $data->Unit->name : ''); ?>"
               data-unit_role="<?php echo e(!empty($data->UnitRole->name) ? $data->UnitRole->name : ''); ?>"
               data-email="<?php echo e(!empty($data->email) ? $data->email : ''); ?>"
               data-phone="<?php echo e(!empty($data->phone) ? $data->phone : ''); ?>"
               data-ba_number="<?php echo e(!empty($data->ba_baf_no) ? $data->ba_baf_no : ''); ?>"

               class="btn btn-info view-data"
               data-toggle="modal" data-target="#viewmodal">View
            </a>
        </td>
        <td><a href="#" class="btn btn-success edit-data"
               data-toggle="modal" data-target="#editmodal"
               data-id="<?php echo e(!empty($data->id) ? $data->id : ''); ?>"
               data-name="<?php echo e(!empty($data->name) ? $data->name : ''); ?>"
               data-unit_id="<?php echo e(!empty($data->unit_id) ? $data->unit_id : ''); ?>"
               data-unit_role_id="<?php echo e(!empty($data->unit_role_id) ? $data->unit_role_id : ''); ?>"
               data-email="<?php echo e(!empty($data->email) ? $data->email : ''); ?>"
               data-phone="<?php echo e(!empty($data->phone) ? $data->phone : ''); ?>"
               data-ba_number="<?php echo e(!empty($data->ba_baf_no) ? $data->ba_baf_no : ''); ?>"

            ><i class="fa fa-edit"></i></a></td>
        <td>
            <form action="#" class="status">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id"  value="<?php echo e($data->id); ?>">
                <button  class="btn  <?php echo $data->status==1 ? 'btn-outline-success' : 'btn-outline-danger'; ?>" onclick="return confirm('Do You Want to sure')"><i
                        class="fa <?php echo $data->status==1 ? 'fa-eye' : 'fa-eye-slash'; ?>"></i></button>
            </form>
        </td>
        <td>
            <form action="#" class="delete">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <button class="btn btn-danger" onclick="return confirm('Do You Want to sure')"><i class="fa fa-trash"></i></button>
            </form>
        </td>
    </tr>
</table>
<?php /**PATH /home/cantonment16/public_html/case/resources/views/superadmin/pages/unit-user/unit-user-button.blade.php ENDPATH**/ ?>