                                    <table id="newcase-complete-subadmin" class="table table-striped table-bordered dt-responsive nowrap w-100 newcase-complete-subadmin">
                                            <thead>
                                            <tr>
                                                <th data-priority="1">Sl.</th>
                                                <th data-priority="2">Case No.</th>
                                                <th>Select</th>
                                                <th>Name</th>
                                                <th>Mobile No.</th>
                                                <th >Vehicle Reg.No</th>

                                                <th>Date of offence</th>
                                                <th>Time of offence</th>
                                                <th>Date Disposal</th>
                                                <!--<th>Time Diposal</th>-->
                                                <th>Location</th>

                                                <th>Vehicle Type</th>
                                                <th >Case Type</th>
                                                <th>Victim Type</th>
                                                <th>Name of MP</th>
                                                <th >Paper Ceased</th>
                                                <th data-priority="3">Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $newcasecomplet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$caseData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($caseData->case_no ?? ''); ?></td>
                                            <td>
                                            <span class="icheck-success d-inline"><input class="check-box" type="checkbox" id="newcase1<?php echo e($caseData->id); ?>" name="chk[]" value="<?php echo e($caseData->id); ?>">
                                                <label for="newcase1<?php echo e($caseData->id); ?>"></label>
                                            </span>
                                            </td>
                                            <td><?php echo e($caseData->victim_name ?? ''); ?></td>
                                            <td><?php echo e($caseData->victim_mb ?? ''); ?></td>
                                            <td><?php echo e($caseData->vehical_reg ?? ''); ?></td>
                                            <td><?php echo e($caseData->date_off ?? ''); ?></td>
                                            <td><?php echo e($caseData->time_off ?? ''); ?></td>
                                            <td><?php echo e($caseData->date_disposal ?? ''); ?></td>
                                            <td><?php echo e($caseData->loc ?? ''); ?></td>
                                            <td><?php echo e($caseData->vehical_type ?? ''); ?></td>
                                            <td>
                                            <?php if($caseData->crime_type!='null'): ?>
                                                <?php $__currentLoopData = json_decode($caseData->crime_type, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $cr=$crimes->where('id',$info ?? '')->first();
                                                    ?>
                                                    <?php echo e($cr->crime ?? ''); ?>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                Null
                                            <?php endif; ?>
                                            </td>
                                            <td><?php echo e($caseData->victim ?? ''); ?></td>
                                            <td><?php echo e(!empty($caseData->Unitauth->name) ? $caseData->Unitauth->name : ''); ?></td>
                                            <td>
                                            <?php if($caseData->paper == 'null'): ?>
                                                null
                                                <?php else: ?>
                                                    <?php $__empty_1 = true; $__currentLoopData = json_decode($caseData->paper, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datapaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <?php echo e($datapaper); ?>,
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                            <table>
                                                <tr>
                                                    <td>
                                                        <a href="" class="btn btn-sm btn-info edit-btn-case-desk" data-toggle="modal" data-id="<?php echo e($caseData->id); ?>" data-target="#exampleModaledit">
                                                        <!-- <i class="fas fa-pencil-alt"> -->
                                                        </i> Edit
                                                        </a>
                                                    </td>
                                                    <td>
                                                    <a href="#" name="buttton" value="singleforward" data-id="<?php echo e($caseData->id); ?>"  class="btn btn-sm btn-danger btn-forward">Forward</a>
                                                    </td>
                                                </tr>
                                                </table>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th data-priority="1">Sl.</th>
                                                <th data-priority="2">Case No.</th>
                                                <th>Select</th>
                                                <th>Name</th>
                                                <th>Mobile No.</th>
                                                <th >Vehicle Reg.No</th>

                                                <th>Date of offence</th>
                                                <th>Time of offence</th>
                                                <th>Date Disposal</th>
                                                <!--<th>Time Diposal</th>-->
                                                <th>Location</th>

                                                <th>Vehicle Type</th>
                                                <th >Case Type</th>
                                                <th>Victim Type</th>
                                                <th>Name of MP</th>
                                                <th >Paper Ceased</th>
                                                <th data-priority="3">Actions</th>
                                            </tr>
                                            </tfoot>
                                </form>
                                </table>
                                <?php echo e($newcasecomplet->links()); ?>

<?php /**PATH /home/cantonment16/public_html/case/resources/views/unitauth/sub-admin/completecase-table.blade.php ENDPATH**/ ?>